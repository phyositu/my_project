<?php

@include "connection.php";
session_start();
if (isset($_POST['submit'])){
    $package_id = $_REQUEST['p_id'];
    $email = $_POST['email'];
    $password = $_POST['pass'];
    $select_user = mysql_query("SELECT * FROM users WHERE email = '$email' AND password='$password'") or die(mysql_error());
    if (mysql_num_rows($select_user) > 0){
        $row = mysql_fetch_assoc($select_user);
        
        if ($row['user_type'] == "user"){
            $_SESSION['user_name'] = $row['name'];
            $_SESSION['user_email'] = $row['email'];
            $_SESSION['user_id'] = $row['id'];
            header("location:books.php?p_id=$package_id");

        }
    }else{
        if (empty($email) || empty($password)){
            $message[] = "Fill your email or password first!";
        }else{
            $message[] = "Inncorect email or password!";

        }
    }

}

        
    

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
	<link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    

</head>
<body>
    <?php
        if(isset($message)){
        foreach ($message as $message) {
            echo' 
                <div class="message">
                    <span> '.$message.'</span>
                    <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
                </div>
            ';
        }
    }
    ?>
    <div class="form-container">
        <form method="POST" enctype="multipart/form-data">
            <h1>Login now</h1>
            <input type="text" placeholder="Enter your email" class="box" name="email"/>
            <input type="password" placeholder="Enter your password" class="box" name="pass"/>
            <input type="submit" value="login" name="submit" class="form-btn"/>
            <p>don't have an account?<a href="register.php?p_id=<?php $package_id = $_REQUEST['p_id']; echo $package_id;?>">register now</a></p>
            

        </form>
    </div>
</body>
</html>