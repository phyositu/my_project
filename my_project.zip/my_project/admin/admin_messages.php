<?php
session_start();
$admin_id = $_SESSION['admin_id'];
if (!isset($admin_id))
{
	header('location:index.php');
}
include "connection.php";
$admin_id = $_SESSION['admin_id'];
if (!isset($admin_id))
{
	header('location:index.php');
}
if (isset($_GET['delete'])){
	$delete_id = $_GET['delete'];
	mysql_query("DELETE FROM messages WHERE id = '$delete_id'") or die('query failed');
	$message[] = "Deleted message successfully";
}



?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>admin messages</title>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
	<link rel="stylesheet" href="../css/admin_style.css">
</head>
<body>
	<?php include "admin_header.php";?>

	<section class="messages">
	<h1 class="title">received messages</h1>

		<div class="box-container">
			
				<table>
						<?php
							$select_messages = mysql_query("SELECT * FROM messages") or die('qurey failed');
							if (mysql_num_rows($select_messages) > 0){
								while($fetch_messages = mysql_fetch_assoc($select_messages)){
						?>
				
					<tr>
					
						<td>
						
							<div class="box">
								<p>user name : <span><?php echo $fetch_messages['name'];?></span></p>
								<p>email : <span><?php echo $fetch_messages['email'];?></span></p>
								<p>ph no : <span><?php echo $fetch_messages['number'];?></span></p>
								<p>message : <span><?php echo $fetch_messages['message'];?></span></p>
								<a href="admin_messages.php?delete=<?php echo $fetch_messages['id']?>" class="delete-btn" onclick="return confirm('delete this message?')">delete</a>
							</div>
						</td>
					</tr>
				</table>
					
			<?php
				}
			}else{
				echo "<p class='empty'>you have no messages.</p>";
			}
			?>
		</div>
	</section>







    <script src="../script/admin_script.js"></script>
    
</body>
</html>
<!-- Lorem, ipsum dolor sit amet consectetur adipisicing elit. Totam alias id neque, ipsum deserunt cumque. Ea molestiae vel maiores in, mollitia eligendi repellendus veritatis natus. Numquam, a. Aliquam, corrupti minus. -->
