<?php

 include "connection.php";
 if (isset($_POST['send'])){
$name = $_POST['name'];
$email = $_POST['email'];
$number = $_POST['number'];
$message = $_POST['message'];

$select_message = mysql_query("SELECT * FROM messages WHERE name = '$name' AND email = '$email' AND number = '$number' AND message = '$message'") or die(mysql_error());
if (mysql_num_rows($select_message) > 0){
	$messages[] ="message already sent!";
}else{
	mysql_query("INSERT INTO messages (name,email,number,message) VALUES('$name','$email','$number','$message')") or die('query failed');
	$messages[] = "message sent successfully";
}

}


if(isset($messages)){
        foreach ($messages as $messages) {
            echo' 
                <div class="message">
                    <span> '.$messages.'</span>
                    <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
                </div>
            ';
        }
    }

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>contact</title>
	<!-- swiper css link -->
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css"/>

	<!-- custom CSS File Link -->
	<link rel="stylesheet" href="style.css">
	<!-- fontawsome cdn link -->
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
	
	<!-- custom CSS File Link -->
	<link rel="stylesheet" href="css/style.css">
</head>
<body>
    
	<!-- header section start -->
	<section class="header">
		<a href="index.php" class="logo">travel.</a>
		<nav class="nav-bar">
			<a href="index.php">home</a>
			<a href="about.php">about</a>
			<a href="packages.php">packages</a>
			<a href="contact.php">contact</a>
		</nav>
		<div id="menu-btn" class="fas fa-bars"></div>
	</section>

	<!-- header section ends -->
	<div class="heading" style="background: url(images/contact-heading.jpg) no-repeat;">
		<h1>contact us</h1>
	</div>
	

<section class="contact">
    <div class="row">
    <div class="image">
        <img src="images/contact.png" alt="">
    </div>
    <form action="" method="POST" enctype="multipart/form-data">
        <h1>send us a message!</h1>
        <input type="text" class="box" name="name" placeholder="enter your name" required>
        <input type="email" class="box" name="email" placeholder="enter your email" required>
        <input type="number" min="0" class="box" name="number" placeholder="enter your phone number" required>
        <textarea name="message" id="" cols="30" rows="10" placeholder="messages" class="box" required></textarea>
        <input type="submit" value="send" name="send" class="form-btn">
    </form>
    </div>
</section>







	<!-- footer section starts -->
	<section class="footer">
		<div class="boxContainer">
			<div class="box">
				<h3>quick links</h3>
				<a href="index.php"><i class="fas fa-angle-right"></i> home</a>
				<a href="about.php"><i class="fas fa-angle-right"></i> about</a>
				<a href="packages.php"><i class="fas fa-angle-right"></i> packages</a>
				<a href="contact.php"><i class="fas fa-angle-right"></i> contact</a>

			</div>
			<div class="box">
				<h3>extra links</h3>
				<a href="#"><i class="fas fa-angle-right"></i> ask questions</a>
				<a href="#"><i class="fas fa-angle-right"></i> about us</a>
				<a href="#"><i class="fas fa-angle-right"></i> privacy policy</a>
				<a href="#"><i class="fas fa-angle-right"></i> term of use</a>
				
				
			</div>
			<div class="box">
				<h3>contract info</h3>
				<a href="#"><i class="fas fa-phone"></i> 123-456-789</a>
				<a href="#"><i class="fas fa-phone"></i> 111-222-333</a>
				<a href="#"><i class="fas fa-envelope"></i> phyosithuaung@gmail.com</a>
				<a href="#"><i class="fas fa-map"></i> yangon, myanmar - 400104</a>

			</div>
			<div class="box">
				<h3>follow us</h3>
				<a href="#"><i class="fab fa-facebook-f"></i>facebook</a>
				<a href="#"><i class="fab fa-twitter"></i>twitter</a>
				<a href="#"><i class="fab fa-instagram"></i>instagram</a>
				<a href="#"><i class="fab fa-linkedin"></i>linkedin</a>

				

			</div>
		</div>
		<div class="credit">created by <span>phyo si thu aung</span> | all right reserved!</div>
	</section>
	<!-- footer section ends -->

	<!-- swiper js link -->
	<script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>
	<script src="script/script.js"></script>
</body>
</html>