<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>about</title>
	<!-- swiper css link -->
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css"/>

	<!-- custom CSS File Link -->
	<link rel="stylesheet" href="style.css">
	<!-- fontawsome cdn link -->
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
	
	<!-- custom CSS File Link -->
	<link rel="stylesheet" href="css/style.css">
</head>
<body>
	<section class="header">
		<a href="index.php" class="logo">travel.</a>
		<nav class="nav-bar">
			<a href="index.php">home</a>
			<a href="about.php">about</a>
			<a href="packages.php">packages</a>
			<a href="contact.php">contact</a>
		</nav>
		<div id="menu-btn" class="fas fa-bars"></div>
	</section>
	<div class="heading" style="background: url(images/about-heading.jpg) no-repeat;">
		<h1>about us</h1>
	</div>
	<!-- about section start -->
	<section class="about">
		<div class="image">
			<img src="images/about-us.jpg" alt="">
		</div>
		<div class="content">
			
			<h3>why choose us?</h3>
			<p>Lorem ipsum dolor sit amet consectetur adipisicing elit
				. Sint consequuntur quidem atque ducimus inventore, debitis ad
				 aliquid enim nulla recusandae, delectus hic harum. Accusamus fuga
				  quaerat hic veniam saepe labore?
				</p>
			<p>Lorem ipsum dolor sit amet consectetur adipisicing elit
				. Officia repellat quibusdam ducimus rem facere est vel 
				libero, accusantium placeat totam.
			</p>
			<div class="icon-container">
				<div class="icon">
					<i class="fas fa-map"></i>
					<span>top destinations</span>
				</div>
				<div class="icon">
					<i class="fas fa-hand-holding-usd"></i>
					<span>affordable price</span>
				</div>
				<div class="icon">
					<i class="fas fa-headset"></i>
					<span>24/7 guide service</span>
				</div>
			</div>
		</div>
	</section>
	<!-- about section ends -->
	<!-- review-section start -->
	<section class="reviews">
		<h1 class="heading-title">client reviews</h1>
		<div class="swiper reviews-slider">
			<div class="swiper-wrapper">
				<div class="swiper-slide slide">
					<div class="stars">
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>

					</div>
					<p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Sequi unde tenetur quos maiores, delectus laudantium reiciendis adipisci, esse minus, asperiores ut odit similique repellendus ipsa! Labore ipsam aut natus iure!</p>
					<h3>john deo</h3>
					<span>traveller</span>
					<img src="images/pic-1.png" alt="">
				</div>
				<div class="swiper-slide slide">
					<div class="stars">
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>

					</div>
					<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Laudantium quibusdam explicabo rerum adipisci a sequi odio quasi omnis. Quibusdam magnam quos quis sapiente deleniti. Voluptates possimus harum accusamus sequi illum, libero corporis, quaerat provident ratione porro ad laboriosam excepturi necessitatibus?</p>
					<h3>rosy</h3>
					<span>traveller</span>
					<img src="images/pic-2.png" alt="">
				</div>
				<div class="swiper-slide slide">
					<div class="stars">
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>

					</div>
					<p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Sequi unde tenetur quos maiores, delectus laudantium reiciendis adipisci, esse minus, asperiores ut odit similique repellendus ipsa! Labore ipsam aut natus iure!</p>
					<h3>james</h3>
					<span>traveller</span>
					<img src="images/pic-3.png" alt="">
				</div>
				<div class="swiper-slide slide">
					<div class="stars">
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						

					</div>
					<p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Sequi unde tenetur quos maiores, delectus laudantium reiciendis adipisci, esse minus, asperiores ut odit similique repellendus ipsa! Labore ipsam aut natus iure!</p>
					<h3>sue</h3>
					<span>traveller</span>
					<img src="images/pic-4.png" alt="" >
				</div>
				<div class="swiper-slide slide">
					<div class="stars">
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						

					</div>
					<p>
						Lorem ipsum dolor sit amet consectetur adipisicing elit. Enim molestiae corporis recusandae nulla, quis nam reiciendis provident vel ullam soluta in, eveniet quaerat possimus fugit labore, cum odio eius! Voluptatem minima aperiam quasi temporibus blanditiis.
					</p>
					<h3>mike</h3>
					<span>traveller</span>
					<img src="images/pic-5.jpg" alt="">
				</div>
				<div class="swiper-slide slide">
					<div class="stars">
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						<i class="fas fa-star"></i>
						

					</div>
					<p>
						Lorem ipsum dolor sit amet consectetur adipisicing elit. Enim molestiae corporis recusandae nulla, quis nam reiciendis provident vel ullam soluta in, eveniet quaerat possimus fugit labore, cum odio eius! Voluptatem minima aperiam quasi temporibus blanditiis.
					</p>
					<h3>kwun</h3>
					<span>traveller</span>
					<img src="images/pic-6.jpg" alt="">
				</div>
			</div>
		</div>
	</section>

	
	<!--review-section ends-->









	<!-- footer section starts -->
	<section class="footer">
		<div class="boxContainer">
			<div class="box">
				<h3>quick links</h3>
				<a href="index.php"><i class="fas fa-angle-right"></i> home</a>
				<a href="about.php"><i class="fas fa-angle-right"></i> about</a>
				<a href="packages.php"><i class="fas fa-angle-right"></i> packages</a>
				<a href="contact.php"><i class="fas fa-angle-right"></i> contact</a>

			</div>
			<div class="box">
				<h3>extra links</h3>
				<a href="#"><i class="fas fa-angle-right"></i> ask questions</a>
				<a href="#"><i class="fas fa-angle-right"></i> about us</a>
				<a href="#"><i class="fas fa-angle-right"></i> privacy policy</a>
				<a href="#"><i class="fas fa-angle-right"></i> term of use</a>
				
				
			</div>
			<div class="box">
				<h3>contract info</h3>
				<a href="#"><i class="fas fa-phone"></i> 123-456-789</a>
				<a href="#"><i class="fas fa-phone"></i> 111-222-333</a>
				<a href="#"><i class="fas fa-envelope"></i> phyosithuaung@gmail.com</a>
				<a href="#"><i class="fas fa-map"></i> yangon, myanmar - 400104</a>

			</div>
			<div class="box">
				<h3>follow us</h3>
				<a href="#"><i class="fab fa-facebook-f"></i>facebook</a>
				<a href="#"><i class="fab fa-twitter"></i>twitter</a>
				<a href="#"><i class="fab fa-instagram"></i>instagram</a>
				<a href="#"><i class="fab fa-linkedin"></i>linkedin</a>

				

			</div>
		</div>
		<div class="credit">created by <span>phyo si thu aung</span> | all right reserved!</div>
	</section>
	<!-- footer section ends -->

	<!-- swiper js link -->
<script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>
<script src="script/script.js"></script>
</body>
</html>