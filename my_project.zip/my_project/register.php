<?php
include "connection.php";
if (isset($_POST['submit']))
{   $package_id = $_REQUEST['p_id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['pass'];
    $cpassword = $_POST['cpass'];
    $select_user = mysql_query("SELECT * FROM users WHERE email = '$email' AND password='$password'") or die(mysql_error());
    if (mysql_num_rows($select_user) > 0){
        $message[] = "user already exist!";
    }
    elseif(strlen($password) < 8){
        $message[] = "your password must be greater than 8";
    }
    elseif($password != $cpassword){
        $message[] = "confirm password not matched!";

    }
    else{
        mysql_query("INSERT INTO users (name,email,password) VALUES('$name','$email','$password')");
        $message [] = 'registered successfully.login now!';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
	<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    

</head>
                
<body>
    <?php
    if(isset($message))
    {
        foreach ($message as $message) {
            echo' 
                <div class="message">
                    <span> '.$message.'</span>
                    <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
                </div>
            ';
        }
    }
    ?>
    
    <div class="form-container">
        <form method="POST" enctype="multipart/form-data">
            <h1>register now</h1>
            <input type="text" placeholder="Enter your name" class="box" name="name" required/>
            <input type="text" placeholder="Enter your email" class="box" name="email" required/>
            <input type="password" placeholder="Enter your password" class="box" name="pass" require/>
            <input type="password" placeholder="confirm your password" class="box" name = "cpass" require/>
            <input type="submit" value="register now" name="submit" class="form-btn"/>
            <p>already have an account?<a href="login.php?p_id=<?php $package_id = $_REQUEST['p_id']; echo $package_id;?>">login now</a></p>
            

        </form>

    </div>
    
</body>
</html>