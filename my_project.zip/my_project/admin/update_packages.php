<?php
include "connection.php";
session_start();
$admin_id = $_SESSION['admin_id'];
if (!isset($admin_id))
{
	header('location:login.php');
}

if (isset($_POST['submit'])){

    $update_p_id = $_POST['update_p_id'];
    $name = $_POST['name'];
    $price = $_POST['price'];
    $detail = $_POST['detail'];
    mysql_query("UPDATE packages SET name = '$name', price = '$price', description = '$detail' WHERE id = '$update_p_id'") or die(mysql_error());
    $image = $_FILES['image']['name'];
	$image_size = $_FILES['image']['size'];
	$image_tmp_name = $_FILES['image']['tmp_name'];
	$image_folder = 'uploaded_img/'.$image;
    $old_img = $_POST['update_p_image'];
    if(!empty($image)){
        if($image_size > 3000000){
            $message[] = 'Image size is too large.';
        }else{
            mysql_query("UPDATE packages SET image = '$image' WHERE id = '$update_p_id'") or die('query failed');
            move_uploaded_file($image_tmp_name,$image_folder);
            unlink('uploaded_img/'.$old_img);

        }
    }
    $message[] = "Package updated successfully";

}


?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>update packages</title>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
	<link rel="stylesheet" href="../css/admin_style.css">
</head>
<body>
	<?php include "admin_header.php";?>
    <section class="update-packages">
        <?php
        $update_id = $_GET['update'];
        $select_packages = mysql_query("SELECT * FROM packages WHERE id = '$update_id'") or die('query failed');
        if (mysql_num_rows($select_packages) > 0){
            while($fetch_packages = mysql_fetch_assoc($select_packages)){

        ?>
<form action="" method="POST" enctype="multipart/form-data">
    <img src="uploaded_img/<?php echo $fetch_packages['image']?>" alt="">
    <input type="hidden" value="<?php echo $fetch_packages['id']?>" class="box" placeholder="enter package name" name="update_p_id" required>
    <input type="hidden" value="<?php echo $fetch_packages['image']?>" class="box" placeholder="enter package name" name="update_p_image" required>
    
    <input type="text" value="<?php echo $fetch_packages['name']?>" class="box" placeholder="enter package name" name="name" required>
    <input type="number" class="box" value="<?php echo $fetch_packages['price'];?>" placeholder="enter package's price" name="price" required>
    <textarea name="detail" class="box" name="detail" placeholder="enter package details" cols="30" rows="10" required>
    <?php echo $fetch_packages['description'];?>
    </textarea>

    <input type="file" class= "box" name = "image">
    <input type="submit" value="update package" class="form-btn" name="submit">
    <a href="admin_packages.php" class="option-btn">go back</a>
</form>
        <?php
            }
        }else{
          echo '<p class="empty">package could not be updated!</p>';
        }
        
        ?>

    </section>
    









<script src="../script/admin_script.js"></script>
    
</body>
</html>
<!-- Lorem, ipsum dolor sit amet consectetur adipisicing elit. Totam alias id neque, ipsum deserunt cumque. Ea molestiae vel maiores in, mollitia eligendi repellendus veritatis natus. Numquam, a. Aliquam, corrupti minus. -->
