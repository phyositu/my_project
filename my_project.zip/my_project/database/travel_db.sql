-- phpMyAdmin SQL Dump
-- version 3.4.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 30, 2023 at 01:31 PM
-- Server version: 5.5.20
-- PHP Version: 5.3.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `travel_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE IF NOT EXISTS `bookings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `package` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `arrival` date NOT NULL,
  `leaving` date NOT NULL,
  `booking_id` varchar(255) DEFAULT NULL,
  `payment_status` varchar(25) DEFAULT 'pending',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `number` varchar(100) NOT NULL,
  `message` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `name`, `email`, `number`, `message`) VALUES
(16, 'Phyo Si Thu Aung', 'phyosithuaung@gmail.com', '232449354959', 'this is a testing a message.\r\n'),
(17, 'Phyo Si Thu Aung', 'phyo@gmail.com', '11324345464', 'this is a testing message!'),
(18, 'Phyo Si Thu Aung', 'phyo@gmail.com', '11324345464', 'this is a testing message!'),
(19, 'si thu aung', 'sithu@gmail.com', '24325436551', 'hello world'),
(20, 'si thu aung', 'sithu@gmail.com', '24325436551', 'hello world'),
(21, 'phyo si thu aung', 'sithu@gmail.com', '252543656', 'this is a testing message!'),
(22, 'phyo si thu aung', 'sithu@gmail.com', '252543656', 'this is a testing message!'),
(25, 'Aung Lay', 'aunglay@gmail.com', '2432546564', 'Hi how are you?'),
(26, 'Aung Aung', 'aung@gmail.com', '123456783', 'hello admin. how are you?'),
(27, 'Aung Aung', 'aung@gmail.com', '123456789', 'hi this is a testing message!');

-- --------------------------------------------------------

--
-- Table structure for table `packages`
--

CREATE TABLE IF NOT EXISTS `packages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) NOT NULL,
  `description` varchar(500) NOT NULL,
  `price` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=58 ;

--
-- Dumping data for table `packages`
--

INSERT INTO `packages` (`id`, `name`, `description`, `price`, `image`) VALUES
(39, 'Package-1', '                            Lorem, ipsum dolor sit amet consectetur adipisicing elit. Totam alias id neque, ipsum deserunt cumque. Ea molestiae vel maiores in, mollitia eligendi repellendus veritatis natus. Numquam, a. Aliquam, corrupti minus.\r\n                            ', 100, 'p-0.1.jpg'),
(40, 'package-2', '                                        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Totam alias id neque, ipsum deserunt cumque. Ea molestiae vel maiores in, mollitia eligendi repellendus veritatis natus. Numquam, a. Aliquam, corrupti minus.                                         ', 200, 'p-10.jpg'),
(41, 'package-3', '                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Totam alias id neque, ipsum deserunt cumque. Ea molestiae vel maiores in, mollitia eligendi repellendus veritatis natus. Numquam, a. Aliquam, corrupti minus.                ', 299, 'p-2.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_type` varchar(59) NOT NULL DEFAULT 'user',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `user_type`) VALUES
(13, 'Mg Mg', 'mg@gmail.com', 'mg123', 'user'),
(14, 'brnyar', 'barnyar@gmail.com', '123', 'admin');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
