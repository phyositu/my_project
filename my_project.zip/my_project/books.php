<?php
session_start();
if(!isset($_SESSION['user_id'])){
header('location:login.php');
}
 include "connection.php";
 if (isset($_POST['submit'])){
$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$address = $_POST['address'];
$package = $_POST['package'];
$price = $_POST['price'];
$arrival = $_POST['arrival'];
$leaving = $_POST['leaving'];
$booking_id = rand(100,500);
if(mysql_query("INSERT INTO bookings(name,email,phone,address,package,price,arrival,leaving,booking_id) VALUES('$name','$email','$phone','$address','$package','$price','$arrival','$leaving','$booking_id')") or die('query failed')){
header("location:booking_success.php?booking_id=$booking_id");

}

}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>My first dynamic project </title>
	<!-- swiper css link -->
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css"/>

	<!-- custom CSS File Link -->
	<link rel="stylesheet" href="style.css">
	<!-- fontawsome cdn link -->
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
	
	<!-- custom CSS File Link -->
	<link rel="stylesheet" href="css/style.css">
</head>
<body>
	<section class="header">
		<a href="index.php" class="logo">travel.</a>
		<nav class="nav-bar">
			<a href="index.php">home</a>
			<a href="about.php">about</a>
			<a href="packages.php">packages</a>
			<a href="contact.php">contact</a>
		</nav>
		<div id="menu-btn" class="fas fa-bars"></div>
	</section>
	
	<div class="heading" style="background:url(images/book-heading.jpg)">
	<h1>book now</h1>
	</div>
	<!-- book section starts -->
	<section class="booking">
		<h1 class="heading-title">book your trip!</h1>
		<?php

		$package_id = $_REQUEST['p_id'];
		$select_packages = mysql_query("SELECT * FROM packages WHERE id = '$package_id'") or die('query failed');
		$fetch_packages = mysql_fetch_assoc($select_packages);
		?>
		
		<form method="POST" class="book-form" enctype="multipart/form-data">
			<div class="flex">
				<div class="input-box">
					<span>name :</span>
					<input type="text" placeholder="enter your name" name="name" value="<?php echo $_SESSION['user_name'];?>" required>
				</div>
				<div class="input-box">
					<span>email :</span>
					<input type="email" placeholder="enter your email" name="email" value="<?php echo $_SESSION['user_email'];?>" required>
				</div>

				<div class="input-box">
					<span>phone :</span>
					<input type="number" placeholder="enter your number" name="phone" required>
				</div>

				<div class="input-box">
					<span>address :</span>
					<input type="text" placeholder="enter your address" name="address" required>
				</div>

				<div class="input-box">
					<span>package you want to visit:</span>
					<input readonly type="text" placeholder="place you want to visit" name="package" value="<?php echo $fetch_packages['name'];  ?>" required>
				</div>

				<div class="input-box">
					<span>price :</span>
					<input readonly type="number" placeholder="price amount" name="price" value="<?php echo $fetch_packages
					['price'];?>" required>
				</div>

				<div class="input-box">
					<span>arrivals :</span>
					<input type="date" name="arrival" required>
				</div>

				<div class="input-box">
					<span>leaving :</span>
					<input type="date" name="leaving" required>
				</div>
			</div>
			<input type="submit" value="submit" class="btn" name="submit">
		</form>
		<?php
		// 	}
		// }
		?>
	</section>
	<!-- book section ends -->

	









	<!-- footer section starts -->
	<section class="footer">
		<div class="boxContainer">
			<div class="box">
				<h3>quick links</h3>
				<a href="index.php"><i class="fas fa-angle-right"></i> home</a>
				<a href="about.php"><i class="fas fa-angle-right"></i> about</a>
				<a href="packages.php"><i class="fas fa-angle-right"></i> packages</a>
				<a href="contact.php"><i class="fas fa-angle-right"></i> contact</a>

			</div>
			<div class="box">
				<h3>extra links</h3>
				<a href="#"><i class="fas fa-angle-right"></i> ask questions</a>
				<a href="#"><i class="fas fa-angle-right"></i> about us</a>
				<a href="#"><i class="fas fa-angle-right"></i> privacy policy</a>
				<a href="#"><i class="fas fa-angle-right"></i> term of use</a>
				
				
			</div>
			<div class="box">
				<h3>contract info</h3>
				<a href="#"><i class="fas fa-phone"></i> 123-456-789</a>
				<a href="#"><i class="fas fa-phone"></i> 111-222-333</a>
				<a href="#"><i class="fas fa-envelope"></i> phyosithuaung@gmail.com</a>
				<a href="#"><i class="fas fa-map"></i> yangon, myanmar - 400104</a>

			</div>
			<div class="box">
				<h3>follow us</h3>
				<a href="#"><i class="fab fa-facebook-f"></i>facebook</a>
				<a href="#"><i class="fab fa-twitter"></i>twitter</a>
				<a href="#"><i class="fab fa-instagram"></i>instagram</a>
				<a href="#"><i class="fab fa-linkedin"></i>linkedin</a>

				

			</div>
		</div>
		<div class="credit">created by <span>phyo si thu aung</span> | all right reserved!</div>
	</section>
	<!-- footer section ends -->

	<!-- swiper js link -->
<script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>
<script src="script/script.js"></script>
</body>
</html>
