<?php
include "connection.php";
session_start();
$admin_id = $_SESSION['admin_id'];
if (!isset($admin_id))
{
	header('location:index.php');
}
if (isset($_POST['update_bookings'])){
	$payment_status = $_POST['update_payment'];
	$booking_id = $_POST['booking_id'];
	if(empty($payment_status)){
		$message[] = "Can't update!choose one option.";
	}else{
		mysql_query("UPDATE bookings SET payment_status = '$payment_status' WHERE booking_id = '$booking_id'") or die('query failed');
		$message[] = "booking updated successfully.";
	}
}elseif (isset($_GET['delete'])){
	$delete_id = $_GET['delete'];
	mysql_query("DELETE FROM bookings WHERE booking_id = '$delete_id'") or die('query failed');
	$message[] = 'booking deleted successfully.';
}




?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>admin bookings</title>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
	<link rel="stylesheet" href="../css/admin_style.css">
</head>
<body>
	<?php include "admin_header.php";?>
<section class="bookings">
	<h1 class="title">placed bookings</h1>
	<div class="box-container">
		<?php
		$select_bookings = mysql_query("SELECT * FROM bookings") or die('query failed');
		if (mysql_num_rows($select_bookings) > 0){
			while ($fetch_bookings = mysql_fetch_assoc($select_bookings)){
		?>
			
				<div class="box">
				<p>booking-id : <span><?php echo $fetch_bookings['booking_id'];?></span></p>
				<p>name : <span><?php echo $fetch_bookings['name'];?></span></p>
				<p>phone : <span><?php echo $fetch_bookings['phone'];?></span></p>
				<p>address : <span><?php echo $fetch_bookings['address'];?></span></p>
				<p>package : <span><?php echo $fetch_bookings['package'];?></span></p>
				<p>price : <span>$<?php echo $fetch_bookings['price'];?></span></p>
				<p>arrival : <span><?php echo $fetch_bookings['arrival'];?></span></p>
				<p>leaving : <span><?php echo $fetch_bookings['leaving'];?></span></p>
				<p>payment status : <span><?php echo $fetch_bookings['payment_status'];?></span></p>
				<form action="" method="post">
					<input type="hidden" name="booking_id" value="<?php echo $fetch_bookings['booking_id'];?>">
					<select name="update_payment" id="">
						<option disibled selected value=""><?php echo $fetch_bookings['payment_status'];?></option>
						<option value="pending">pending</option>
						<option value="completed">completed</option>

					</select>
					<input type="submit" name="update_bookings" value="update" class="option-btn" >
					<a href="admin_bookings.php?delete=<?php echo $fetch_bookings['booking_id'];?>" class="delete-btn" onclick="return confirm('delete this booking?');">delete</a>
				</form>
				
				</div>
		<?php
		}
	}else{
		echo '<p class="empty">no booking placed!</p>';
	}
		?>
	</div>
	
</section>



<script src="../script/admin_script.js"></script>
    
</body>
</html>
<!-- Lorem, ipsum dolor sit amet consectetur adipisicing elit. Totam alias id neque, ipsum deserunt cumque. Ea molestiae vel maiores in, mollitia eligendi repellendus veritatis natus. Numquam, a. Aliquam, corrupti minus. -->
