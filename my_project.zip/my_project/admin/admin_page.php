<?php
include "connection.php";
session_start();
$admin_id = $_SESSION['admin_id'];
if (!isset($admin_id)){
	header('location:index.php');
}

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>admin panel</title>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
	<link rel="stylesheet" href="../css/admin_style.css">
</head>
<body>
	<?php include "admin_header.php";?>

	<!-- admin dashboard section start -->
	<section class="dashboard">
		<h1 class="title">dashboard</h1>
		
		<div class="box-container">
			<div class="box">
				<?php
				$total_pendings = 0;
				$select_pendings = mysql_query("SELECT price FROM bookings WHERE payment_status='pending'") or die('query failed');
				 if (mysql_num_rows($select_pendings)> 0){
					while ($fetch_pendings = mysql_fetch_assoc($select_pendings)) {
						$total_price = $fetch_pendings['price'];
						$total_pendings += $total_price;
					}

				
				 }
					
				?>
				
				<h3>$<?php echo $total_pendings;?>/-</h3>
				<p>total pendings</p>
			</div>
			<div class="box">
				<?php
				$total_completed = 0;
				$select_completed = mysql_query("SELECT price FROM bookings WHERE payment_status='completed'") or die('query failed');
				 if (mysql_num_rows($select_completed)> 0){
					while ($fetch_completed = mysql_fetch_assoc($select_completed)) {
						$total_price = $fetch_completed['price'];
						$total_completed += $total_price;
					}
				 }
					
				?>
				
				<h3>$<?php echo $total_completed;?>/-</h3>
				<p>completed payments</p>
			</div>

			<div class="box">
				<?php
				$select_bookings = mysql_query("SELECT * FROM bookings");
				$total_bookings = mysql_num_rows($select_bookings);
				?>
				<h3><?php echo $total_bookings?></h3>
				<p>booking placed</p>
			</div>

			<div class="box">
				<?php
				$select_packages = mysql_query("SELECT * FROM packages");
				$total_packages = mysql_num_rows($select_packages);
				?>
				<h3><?php echo $total_packages?></h3>
				<p>packages added</p>
			</div>

			<div class="box">
				<?php
				$select_users = mysql_query("SELECT * FROM users WHERE user_type = 'user'");
				$total_users = mysql_num_rows($select_users);
				?>
				<h3><?php echo $total_users?></h3>
				<p>normal user</p>
			</div>
			
			<div class="box">
				<?php
				$select_admins = mysql_query("SELECT * FROM users WHERE user_type = 'admin'");
				$total_admins = mysql_num_rows($select_admins);
				?>
				<h3><?php echo $total_admins?></h3>
				<p>admin user</p>
			</div>
			<div class="box">
				<?php
				$select_accounts = mysql_query("SELECT * FROM users");
				$total_accounts = mysql_num_rows($select_accounts);
				?>
				<h3><?php echo $total_accounts?></h3>
				<p>total user</p>
			</div>
			<div class="box">
				<?php
				$select_messages = mysql_query("SELECT * FROM messages");
				$total_messages = mysql_num_rows($select_messages);
				?>
				<h3><?php echo $total_messages?></h3>
				<p>new messages</p>
			</div>
		</div>
	</section>
	<!-- admin dashboard section end -->










<script src="../script/admin_script.js"></script>

</body>
</html>