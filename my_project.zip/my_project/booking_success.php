
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>booking success</title>
	<link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    

</head>
<body>
    <section class="header">
		<a href="index.php" class="logo">travel.</a>
		<nav class="nav-bar">
			<a href="index.php">home</a>
			<a href="about.php">about</a>
			<a href="packages.php">packages</a>
			<a href="contact.php">contact</a>
		</nav>
		<div id="menu-btn" class="fas fa-bars"></div>
	</section>
    
    <div class="booking-success-container">
        <div class="success">
            <h3>awsome!</h3>
            <div class="message">
                <p>Your booking has been confirmed.</p>
                <p>Your booking ID is <?php echo $_GET['booking_id'];?> and check your Email for  more detail.</p>
            </div>
            <a href="index.php" class="success-btn">ok</a>
        </div>
    </div>
</body>
</html>