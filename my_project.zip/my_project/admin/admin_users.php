<?php
include "connection.php";
session_start();
$admin_id = $_SESSION['admin_id'];
if (!isset($admin_id))
{
	header('location:index.php');
}
if (isset($_GET['delete'])){
	$delete_id = $_GET['delete'];
	mysql_query("DELETE FROM users WHERE id = '$delete_id'") or die('query failed');
	$message[] = "Deleted successfully";
}elseif(isset($_GET['update'])){
	$update_id = $_GET['update'];
	$select_admin = mysql_query("SELECT * FROM users WHERE id = '$update_id'");
	$row = mysql_fetch_assoc($select_admin);
	if($row['user_type'] == 'admin'){
		$message[] = $row['name']." is already admin!";
	}else{
		mysql_query("UPDATE users SET user_type = 'admin' WHERE id = '$update_id'") or die('query failed');
		$message[] = "Set as admin successfully.";
	}
	
}



?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>admin users</title>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
	<link rel="stylesheet" href="../css/admin_style.css">
</head>
<body>
	<?php include "admin_header.php";?>

	<section class="users">
		<h1 class="title">user accounts</h1>
		<div class="box-container">
			<?php
			$select_users = mysql_query("SELECT * FROM users") or die('query failed');
			if (mysql_num_rows($select_users)> 0){
				while ($fetch_users = mysql_fetch_assoc($select_users)){
			?>
			<div class="box">
				<p>user id : <span><?php echo $fetch_users['id'];?></span></p>
				<p>user name : <span><?php echo $fetch_users['name'];?></span></p>
				<p>email : <span><?php echo $fetch_users['email'];?></span></p>
				<p>user type : <span style="<?php if ($fetch_users['user_type']=='admin'){echo 'color:var(--red)';}?>"><?php echo $fetch_users['user_type'];?></span></p>
				<a href="admin_users.php?delete=<?php echo $fetch_users['id']?>" class="delete-btn" onclick="return confirm('delete this user?');">delete</a>
				<a href="admin_users.php?update=<?php echo $fetch_users['id']?>" class="option-btn" onclick="return confirm('set as admin this user?');">set admin</a>

			</div>
			<?php
			}
		}else{
			echo '<p class="empty">no user registered!</p>';
		}
			?>
		</div>
	</section>

<script src="../script/admin_script.js"></script>
    
</body>
</html>
