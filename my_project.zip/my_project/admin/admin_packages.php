<?php
include "connection.php";
session_start();
$admin_id = $_SESSION['admin_id'];
if (!isset($admin_id)){
	header('location:index.php');
}
if (isset($_POST['submit'])){
	$name = $_POST['name'];
	$price = $_POST['price'];
	$detail = $_POST['detail'];
	$image = $_FILES['image']['name'];
	$image_size = $_FILES['image']['size'];
	$image_tmp_name = $_FILES['image']['tmp_name'];
	$image_folder = 'uploaded_img/'.$image;
	$select_package_name = mysql_query("SELECT name FROM packages WHERE name = '$name'") or die('query failed');
	// echo php_ini_loaded_file();
	// echo $image_size;
	
	if(mysql_num_rows($select_package_name) > 0){
		$message[] = 'Package already exist!';
	}
	else{
		if ($image_size > 3000000){
			$message[] = 'Your image size is too large';
		}else{
			$insert_package =  mysql_query("INSERT INTO packages (name,description,price,image) VALUES('$name','$detail','$price','$image')") or die('query failed');
				move_uploaded_file($image_tmp_name,$image_folder);
				$message [] = 'Package added successfully.';
		}
	}
}elseif (isset($_GET['delete'])){
	$delete_id = $_GET['delete'];
	$delete_image = mysql_query("SELECT image FROM packages WHERE id = '$delete_id'") or die('query failed');
	$fetch_delete_image = mysql_fetch_assoc($delete_image);
	unlink('uploaded_img/'.$fetch_delete_image['image']);
	mysql_query("DELETE FROM packages WHERE id = '$delete_id'") or die('query failed');
	$message[] = "Package deleted successfully.";
}
	


	



?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>admin packages</title>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
	<link rel="stylesheet" href="../css/admin_style.css">
</head>
<body>
    <?php include('admin_header.php')?>
<!-- package CRUD section start -->
<section class="add-packages">
    <form action="" method="POST" enctype="multipart/form-data">
        <h3>add new package</h3>
        <input type="text" class="box" placeholder="enter package name" name="name" required>
		<input type="number" class="box" placeholder="enter package's price" name="price" required>
		<textarea name="detail" class="box" name="detail" placeholder="enter package details" cols="30" rows="10" required></textarea>
		<input type="file" class= "box" name = "image" required>
		<input type="submit" value="add package" class="form-btn" name="submit">
	
	</form>

</section>
<section class="show-packages">
	<h3>added packages</h3>
	<div class="box-container">
		<?php
		$select_package = mysql_query("SELECT * FROM packages") or die("query failed");
		if(mysql_num_rows($select_package) > 0){
			while($fetch_package = mysql_fetch_assoc($select_package)){
		?>
		<div class="box">
			<img class="image" src="uploaded_img/<?php echo $fetch_package['image'];?>" alt="">
			<div class="name"><?php echo $fetch_package['name'];?></div>
			
			<div class="price">$<?php echo $fetch_package['price'];?>/-</div>
			<div class="detail"><?php echo $fetch_package['description'];?></div>
			<a href="update_packages.php?update=<?php echo $fetch_package['id'];?>" class="option-btn">update</a>
			<a href="admin_packages.php?delete=<?php echo $fetch_package['id'];?>" class="delete-btn" onclick="return confirm('delete this package?');">delete</a>

		
		</div>
		<?php		
			}
		}else{
			echo '<p class="empty">no package add yet!</p>';
		}
		?>
	</div>
</section>

<!-- package CRUD section end-->









<script src="../script/admin_script.js"></script>

</body>
</html>
<!-- Lorem, ipsum dolor sit amet consectetur adipisicing elit. Totam alias id neque, ipsum deserunt cumque. Ea molestiae vel maiores in, mollitia eligendi repellendus veritatis natus. Numquam, a. Aliquam, corrupti minus. -->
