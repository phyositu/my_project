<?php 
include('connection.php');
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>packages </title>
	<!-- swiper css link -->
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css"/>

	<!-- custom CSS File Link -->
	<link rel="stylesheet" href="style.css">
	<!-- fontawsome cdn link -->
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
	
	<!-- custom CSS File Link -->
	<link rel="stylesheet" href="css/style.css">
</head>
<body>
<section class="header">
		<a href="index.php" class="logo">travel.</a>
		<nav class="nav-bar">
			<a href="index.php">home</a>
			<a href="about.php">about</a>
			<a href="packages.php">packages</a>
			<a href="contact.php">contact</a>
		</nav>
		<div id="menu-btn" class="fas fa-bars"></div>
	</section>
	<div class="heading" style="background:url(images/package-heading.jpg);">
	<h1>packages</h1>
	</div>
	<!-- package ssection starts -->
	
	<section class="packages">
		<h1 class="heading-title">top destinations</h1>
		<div class="box-container">
			<?php
			$select_packages = mysql_query("SELECT * FROM packages") or die('query failed');
			if (mysql_num_rows($select_packages)> 0){
				while ($fetch_packages = mysql_fetch_assoc($select_packages)){
			?>
			<div class="box">
				<div class="image">
					<img src="admin/uploaded_img/<?php echo $fetch_packages['image'];?>" alt="">
				</div>
				<div class="content">
					<h3><?php echo $fetch_packages['name'];?></h3>
					<div class="price">$<?php echo $fetch_packages['price'];?>/-</div>
					<p><?php echo $fetch_packages['description'];?></p>
					<a href="login.php?p_id=<?php echo $fetch_packages['id'];?>" class="btn">book now</a>
				</div>
			</div>
			<?php
			}
		}
			?>
			
			
	</section>
	<!-- package section ends -->









	<!-- footer section starts -->
	<section class="footer">
		<div class="boxContainer">
			<div class="box">
				<h3>quick links</h3>
				<a href="index.php"><i class="fas fa-angle-right"></i> home</a>
				<a href="about.php"><i class="fas fa-angle-right"></i> about</a>
				<a href="packages.php"><i class="fas fa-angle-right"></i> packages</a>
				<a href="contact.php"><i class="fas fa-angle-right"></i> contact</a>

			</div>
			<div class="box">
				<h3>extra links</h3>
				<a href="#"><i class="fas fa-angle-right"></i> ask questions</a>
				<a href="#"><i class="fas fa-angle-right"></i> about us</a>
				<a href="#"><i class="fas fa-angle-right"></i> privacy policy</a>
				<a href="#"><i class="fas fa-angle-right"></i> term of use</a>
				
				
			</div>
			<div class="box">
				<h3>contract info</h3>
				<a href="#"><i class="fas fa-phone"></i> 123-456-789</a>
				<a href="#"><i class="fas fa-phone"></i> 111-222-333</a>
				<a href="#"><i class="fas fa-envelope"></i> phyosithuaung@gmail.com</a>
				<a href="#"><i class="fas fa-map"></i> yangon, myanmar - 400104</a>

			</div>
			<div class="box">
				<h3>follow us</h3>
				<a href="#"><i class="fab fa-facebook-f"></i>facebook</a>
				<a href="#"><i class="fab fa-twitter"></i>twitter</a>
				<a href="#"><i class="fab fa-instagram"></i>instagram</a>
				<a href="#"><i class="fab fa-linkedin"></i>linkedin</a>

				

			</div>
		</div>
		<div class="credit">created by <span>phyo si thu aung</span> | all right reserved!</div>
	</section>
	<!-- footer section ends -->

	<!-- swiper js link -->
<script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>
<script src="script/script.js"></script>
</body>
</html>